# PathSignal presentation release

## Experimental stair mode

The 20 November update adds optional SegFormer-B0 stair-region segmentation. It misses the supplied downward-looking example. See `public/stair-development-notes.md` and the full license at `public/licenses/SEGFORMER-LICENSE.txt`. This component is for non-commercial research and evaluation. Camera height remains unknown and metric distance is disabled. The original object detector is the default mode.


A separate React and TypeScript browser app for the final-year presentation. The existing Expo app remains in `../phone`.

Run `npm ci`, `npm run build`, then `npm run preview`. Camera access on another device requires HTTPS. Deploy configuration is in `.openai/hosting.json`.

This release uses the existing pretrained YOLOX-S model. No additional model training was performed. Read `public/project-report.md`, `public/presentation-guide.md`, `public/evaluation-plan.md` and `public/technical-notes.md` for scope, attribution and demonstration instructions.

Generated `public/model` and `public/runtime` assets are rebuilt from tracked source-model parts and the pinned ONNX Runtime dependency. The production build is in `dist`.
