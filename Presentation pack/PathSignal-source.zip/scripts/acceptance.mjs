import { chromium, webkit } from 'playwright'
import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
const base = process.env.PATHSIGNAL_URL || 'http://127.0.0.1:4173'
const browserType = process.argv.includes('--webkit') ? webkit : chromium
const browser = await browserType.launch({ headless: true, ...(browserType === chromium ? { channel: 'chrome' } : {}) })
const page = await browser.newPage({ viewport: { width: 1440, height: 1100 } })
const errors = []
const requests = []
page.on('pageerror', error => errors.push(error.message))
page.on('request', request => requests.push({ url: request.url(), method: request.method() }))
await page.addInitScript(() => {
  window.testSpeech = []
  Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak: message => window.testSpeech.push(message.text), cancel: () => {} } })
  if (!window.SpeechSynthesisUtterance) window.SpeechSynthesisUtterance = class { constructor(text) { this.text = text } }
})
try {
  assert.equal((await page.goto(base)).status(), 200)
  await page.getByRole('heading', { name: 'Point. Scan. Listen.' }).waitFor()
  await page.getByRole('button', { name: 'Load AI model', exact: true }).click()
  await page.getByText('YOLOX-S ready · processing stays on this device', { exact: true }).waitFor({ timeout: 150000 })
  await page.getByRole('button', { name: 'Test audio', exact: true }).click()
  assert((await page.evaluate(() => window.testSpeech)).includes('PathSignal audio check.'))
  await page.getByRole('button', { name: 'Black bottle Object-present sample' }).click()
  await page.getByText('Possible obstacle in the corridor', { exact: true }).waitFor({ timeout: 35000 })
  assert((await page.evaluate(() => window.testSpeech)).some(text => text.includes('bottle')))
  const bottle = await page.locator('.scan-status').innerText()
  await page.getByRole('button', { name: 'Empty floor Negative-control sample' }).click()
  await page.getByText('No alert on this scan', { exact: true }).waitFor({ timeout: 35000 })
  const sampleSpeech = await page.evaluate(() => window.testSpeech)
  assert.equal(sampleSpeech.filter(text => text.includes('Possible')).length, 1)
  await page.getByRole('button', { name: 'View session log' }).click()
  assert.equal(await page.locator('tbody tr').count(), 2)
  const exported = page.waitForEvent('download')
  await page.getByRole('button', { name: 'CSV', exact: true }).click()
  assert.equal((await exported).suggestedFilename(), 'pathsignal-session.csv')
  await page.locator('input[type="file"]').setInputFiles('public/samples/bottle.jpg')
  await page.getByText('Possible obstacle in the corridor', { exact: true }).waitFor({ timeout: 35000 })
  assert.equal(await page.locator('tbody tr').count(), 3)
  await page.reload()
  await page.getByRole('button', { name: 'View session log' }).click()
  assert.equal(await page.locator('tbody tr').count(), 3)
  // Use a real canvas MediaStream to exercise camera lifecycle and encounter gating.
  await page.getByRole('button', { name: 'Load AI model', exact: true }).click()
  await page.getByText('YOLOX-S ready · processing stays on this device', { exact: true }).waitFor({ timeout: 150000 })
  if (browserType === chromium) {
  await page.evaluate(async () => {
    window.testFloor = false
    const bottle = new Image(), floor = new Image()
    await Promise.all([new Promise(resolve => { bottle.onload = resolve; bottle.src = '/samples/bottle.jpg' }), new Promise(resolve => { floor.onload = resolve; floor.src = '/samples/floor.jpg' })])
    const canvas = document.createElement('canvas'); canvas.width = 480; canvas.height = 270
    const context = canvas.getContext('2d')
    window.testCameraCanvas = canvas
    window.testCameraInterval = setInterval(() => context.drawImage(window.testFloor ? floor : bottle, 0, 0, 480, 270), 50)
    context.drawImage(bottle, 0, 0, 480, 270)
    const stream = canvas.captureStream(10)
    window.testStream = stream
    navigator.mediaDevices.getUserMedia = async () => stream
  })
    await page.getByRole('button', { name: 'Start camera', exact: true }).click()
    await page.getByText('Camera ready. Stand still and scan.', { exact: true }).waitFor({ timeout: 10000 })
    async function scan() {
      await page.getByRole('button', { name: 'Scan now', exact: true }).click()
      await page.waitForFunction(() => !document.querySelector('.scanning-badge'), null, { timeout: 35000 })
    }
    await scan(); await scan()
    assert.equal((await page.evaluate(() => window.testSpeech)).filter(text => text.includes('Possible')).length, 1)
    await page.evaluate(() => { window.testFloor = true }); await page.waitForTimeout(200)
    await scan(); await scan()
    await page.evaluate(() => { window.testFloor = false }); await page.waitForTimeout(200)
    await scan()
    assert.equal((await page.evaluate(() => window.testSpeech)).filter(text => text.includes('Possible')).length, 2)
    const rowsBefore = await page.locator('tbody tr').count()
    await page.getByRole('button', { name: 'Start repeated scans', exact: true }).click()
    await page.waitForFunction(count => document.querySelectorAll('tbody tr').length >= count + 2, rowsBefore, { timeout: 35000 })
    await page.getByRole('button', { name: 'Stop repeated scans', exact: true }).click()
    await page.getByRole('button', { name: 'Stop', exact: true }).click()
    assert.equal(await page.evaluate(() => window.testStream.getTracks()[0].readyState), 'ended')
    await page.evaluate(() => { clearInterval(window.testCameraInterval); navigator.mediaDevices.getUserMedia = async () => { throw new DOMException('Denied', 'NotAllowedError') } })
    await page.getByRole('button', { name: 'Start camera', exact: true }).click()
    await page.getByText('Camera permission was denied. Allow camera access in browser settings.', { exact: true }).waitFor()
    assert((await page.evaluate(() => window.testSpeech)).some(text => text.includes('Obstacle alerts paused')))
  }
  mkdirSync('verification', { recursive: true })
  await page.evaluate(() => window.scrollTo(0, 0))
  await page.screenshot({ path: `verification/${browserType.name()}-desktop.png`, fullPage: true })
  await page.setViewportSize({ width: 390, height: 844 })
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false)
  await page.screenshot({ path: `verification/${browserType.name()}-mobile.png`, fullPage: true })
  for (const path of ['/project-report.md', '/presentation-guide.md', '/evaluation-plan.md', '/technical-notes.md', '/licenses/YOLOX-LICENSE.txt', '/licenses/ONNX-RUNTIME-LICENSE.txt', '/licenses/REACT-LICENSE.txt']) {
    assert.equal((await page.request.get(base + path)).status(), 200, path)
  }
  assert.equal(requests.some(item => item.method !== 'GET'), false, 'No image or log uploads expected')
  assert.deepEqual(errors, [])
  const report = { browser: browserType.name(), base, bottleResult: bottle, emptyFloor: 'no alert', sampleSpeech, logRestored: true,
    cameraLifecycle: browserType === chromium ? 'canvas stream, encounter suppression and re-arm, repeated scans, stop and denial passed' : 'not checked', imageUpload: 'passed', mobileWidth: 390, horizontalOverflow: false, pageErrors: errors,
    note: 'Desktop browser automation. Speech calls observed; sound and physical iPhone camera unverified.' }
  writeFileSync(`verification/${browserType.name()}-results.json`, JSON.stringify(report, null, 2))
  console.log(JSON.stringify(report))
} finally { await browser.close() }
