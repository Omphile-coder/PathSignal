import { mkdirSync, cpSync, readFileSync, writeFileSync } from 'node:fs'
import { build } from 'esbuild'
mkdirSync('dist/assets', { recursive: true })
cpSync('public', 'dist', { recursive: true })
await build({ entryPoints: ['src/main.tsx'], outfile: 'dist/assets/app.js', bundle: true, minify: true,
  format: 'esm', target: 'safari16', jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"' } })
const html = readFileSync('index.html', 'utf8').replace('/src/main.tsx', '/assets/app.js').replace('</head>', '<link rel="stylesheet" href="/assets/app.css"/></head>')
writeFileSync('dist/index.html', html)
console.log('Built static presentation release in dist')
