import { chromium, webkit } from 'playwright'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
const engine = process.argv.includes('--webkit') ? webkit : chromium
const browser = await engine.launch({ headless: true, ...(engine === chromium ? { channel: 'chrome' } : {}) })
const base = process.env.PATHSIGNAL_URL || 'http://127.0.0.1:4173'
try {
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } })
  const errors = []
  page.on('pageerror', error => errors.push(error.message))
  await page.addInitScript(() => {
    window.testSpeech = []
    Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak: message => window.testSpeech.push(message.text), cancel() {} } })
    if (!window.SpeechSynthesisUtterance) window.SpeechSynthesisUtterance = class { constructor(text) { this.text = text } }
  })
  await page.goto(base)
  await page.getByRole('button', { name: 'Stairs (experimental)', exact: true }).click()
  await page.getByRole('button', { name: 'Load AI model', exact: true }).click()
  await page.getByText('Experimental stair model ready · SegFormer-B0', { exact: true }).waitFor({ timeout: 150000 })
  const checks = [
    ['Facing upstairs Stair example', 'Possible stairs in the corridor'],
    ['Looking downstairs Known missed example', 'No alert on this scan'],
    ['Dark markings Check false stair alerts', 'No alert on this scan'],
    ['Empty floor Negative-control sample', 'No alert on this scan'],
  ]
  for (const [button, outcome] of checks) {
    await page.getByRole('button', { name: button, exact: true }).click()
    await page.waitForFunction(() => !document.querySelector('.scanning-badge'), null, { timeout: 35000 })
    await page.getByText(outcome, { exact: true }).waitFor({ timeout: 35000 })
  }
  const speech = await page.evaluate(() => window.testSpeech)
  assert.deepEqual(speech, ['Possible stairs ahead.'])
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false)
  await page.getByRole('button', { name: 'View session log' }).click()
  assert.equal(await page.locator('tbody tr').count(), 4)
  assert.equal(await page.locator('tbody').getByText('SegFormer-B0', { exact: true }).count(), 4)
  await page.getByRole('button', { name: 'Facing upstairs Stair example', exact: true }).click()
  await page.getByText('Possible stairs in the corridor', { exact: true }).waitFor({ timeout: 35000 })
  await page.locator('#demo').screenshot({ path: `verification/stairs-${engine.name()}-mobile.png` })
  assert.equal((await page.request.get(base + '/licenses/SEGFORMER-LICENSE.txt')).status(), 200)
  await page.getByRole('button', { name: 'Everyday objects', exact: true }).click()
  assert.equal(await page.getByRole('button', { name: 'Load AI model', exact: true }).count(), 1)
  assert.equal(await page.getByRole('button', { name: 'Black bottle Object-present sample', exact: true }).isDisabled(), true)
  assert.deepEqual(errors, [])
  const report = { engine: engine.name(), checks, speechRequests: speech, mobileWidth: 390, overflow: false, modeSwitchResetsModel: true,
    note: 'Known downward-view failure is expected and surfaced. These development examples are not independent validation. Sound and physical camera unverified.' }
  writeFileSync(`verification/stairs-${engine.name()}-results.json`, JSON.stringify(report, null, 2))
  console.log(JSON.stringify(report))
  if (process.argv.includes('--frames')) {
    const frameRoot = '../calibration-review/2026-11-20/frames'
    await page.evaluate(() => {
      window.stairEvents = []
      window.stairWorker = new Worker('/model/stairs-worker.js')
      window.stairWorker.onmessage = event => window.stairEvents.push(event.data)
    })
    await page.waitForFunction(() => window.stairEvents.some(event => event.type === 'ready' || event.type === 'failed'), null, { timeout: 150000 })
    const rows = []
    for (const [index, name] of readdirSync(frameRoot).filter(name => name.endsWith('.jpg')).entries()) {
      const id = index + 1
      const data = readFileSync(frameRoot + '/' + name).toString('base64')
      await page.evaluate(async ({ data, id }) => {
        const image = new Image()
        await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; image.src = 'data:image/jpeg;base64,' + data })
        const canvas = document.createElement('canvas'); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight
        const context = canvas.getContext('2d'); context.drawImage(image, 0, 0)
        const rgba = context.getImageData(0, 0, canvas.width, canvas.height).data.buffer
        window.stairWorker.postMessage({ id, rgba, width: canvas.width, height: canvas.height }, [rgba])
      }, { data, id })
      await page.waitForFunction(id => window.stairEvents.some(event => event.id === id && ['result', 'error'].includes(event.type)), id, { timeout: 35000 })
      const output = await page.evaluate(id => window.stairEvents.find(event => event.id === id && ['result', 'error'].includes(event.type)), id)
      assert.equal(output.type, 'result', JSON.stringify(output))
      const row = { file: name, alert: output.hazards.length > 0, fraction: output.stairFraction, milliseconds: output.milliseconds }
      rows.push(row); console.log(JSON.stringify(row))
    }
    await page.evaluate(() => window.stairWorker.terminate())
    writeFileSync('verification/stair-development-frames.json', JSON.stringify({ model: 'SegFormer-B0 quantized', cameraHeight: 'unknown', metreEstimates: 'disabled',
      threshold: { pixelSupport: .5, corridorCoverage: .05 }, note: 'Three frames per development clip, correlated and not independent trials. Original stairs-up label shows downstairs, stairs-down shows upstairs. Dark markings include damaged paving of unverified geometry.', rows }, null, 2))
  }
} finally { await browser.close() }
