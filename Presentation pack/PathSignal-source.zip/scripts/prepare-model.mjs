import { mkdirSync, readFileSync, writeFileSync, copyFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { build } from 'esbuild'
const hash = b => createHash('sha256').update(b).digest('hex')
const manifest = JSON.parse(readFileSync('source-model/manifest.json', 'utf8'))
const modelBuffers = []
mkdirSync('public/model', { recursive: true })
mkdirSync('public/runtime', { recursive: true })
for (const part of manifest.parts) {
  const bytes = readFileSync('source-model/' + part.file)
  if (bytes.length !== part.bytes || hash(bytes) !== part.sha256) throw Error('Model integrity check failed')
  modelBuffers.push(bytes)
}
const completeModel = Buffer.concat(modelBuffers)
const webParts = []
for (let offset = 0; offset < completeModel.length; offset += 2000000) {
  const bytes = completeModel.subarray(offset, Math.min(completeModel.length, offset + 2000000))
  const file = `yolox-s-web-${webParts.length}.bin`
  writeFileSync('public/model/' + file, bytes)
  webParts.push({ file, bytes: bytes.length, sha256: hash(bytes) })
}
writeFileSync('public/model/manifest.json', JSON.stringify({ name: manifest.name, bytes: manifest.bytes, parts: webParts }))
for (const file of ['ort.wasm.min.js', 'ort-wasm-simd-threaded.mjs', 'ort-wasm-simd-threaded.wasm']) {
  copyFileSync('node_modules/onnxruntime-web/dist/' + file, 'public/runtime/' + file)
}
await build({ entryPoints: ['src/detector.worker.ts'], outfile: 'public/model/worker.js', bundle: true,
  format: 'iife', target: 'safari16', platform: 'browser', minify: true })
const stairs = readFileSync('source-model/stairs.onnx')
const stairManifest = JSON.parse(readFileSync('source-model/stairs-manifest.json', 'utf8'))
if (stairs.length !== stairManifest.bytes || hash(stairs) !== stairManifest.sha256) throw Error('Stair model integrity check failed')
copyFileSync('source-model/stairs.onnx', 'public/model/stairs.onnx')
copyFileSync('source-model/stairs-manifest.json', 'public/model/stairs-manifest.json')
await build({ entryPoints: ['src/stairs.worker.ts'], outfile: 'public/model/stairs-worker.js', bundle: true,
  format: 'iife', target: 'safari16', platform: 'browser', minify: true })
console.log('Prepared YOLOX-S model, checked SHA-256 and bundled inference worker')
