import { mkdirSync, readFileSync, writeFileSync, copyFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { build } from 'esbuild'
const hash = b => createHash('sha256').update(b).digest('hex')
const manifest = JSON.parse(readFileSync('source-model/manifest.json', 'utf8'))
mkdirSync('public/model', { recursive: true })
mkdirSync('public/runtime', { recursive: true })
for (const part of manifest.parts) {
  const bytes = readFileSync('source-model/' + part.file)
  if (bytes.length !== part.bytes || hash(bytes) !== part.sha256) throw Error('Model integrity check failed')
  copyFileSync('source-model/' + part.file, 'public/model/' + part.file)
}
writeFileSync('public/model/manifest.json', JSON.stringify(manifest))
for (const file of ['ort.wasm.min.js', 'ort-wasm-simd-threaded.mjs', 'ort-wasm-simd-threaded.wasm']) {
  copyFileSync('node_modules/onnxruntime-web/dist/' + file, 'public/runtime/' + file)
}
await build({ entryPoints: ['src/detector.worker.ts'], outfile: 'public/model/worker.js', bundle: true,
  format: 'iife', target: 'safari16', platform: 'browser', minify: true })
console.log('Prepared YOLOX-S model, checked SHA-256 and bundled inference worker')
