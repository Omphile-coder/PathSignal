import http from 'node:http'
import { createReadStream, statSync } from 'node:fs'
import path from 'node:path'
const root = path.resolve('dist')
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.wasm': 'application/wasm', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.md': 'text/markdown; charset=utf-8', '.txt': 'text/plain; charset=utf-8' }
http.createServer((request, response) => {
  let target
  try {
    const route = decodeURIComponent(new URL(request.url, 'http://localhost').pathname)
    target = path.resolve(root, '.' + (route === '/' ? '/index.html' : route))
    if (!target.startsWith(root + path.sep) || !statSync(target).isFile()) throw Error('Not found')
  } catch { response.writeHead(404); response.end('Not found'); return }
  response.writeHead(200, { 'Content-Type': mime[path.extname(target)] || 'application/octet-stream', 'Cache-Control': 'no-store' })
  createReadStream(target).pipe(response)
}).listen(4173, '127.0.0.1', () => console.log('Local: http://127.0.0.1:4173'))
