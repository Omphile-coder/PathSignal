import { decodeYolo, makeYoloInput, YOLOX_SIZE } from './yoloxDecode'
import { pathHazards } from './path'
import type * as Ort from 'onnxruntime-web'
declare const self: { importScripts(url: string): void; ort: typeof Ort; postMessage(message: unknown): void; onmessage: (event: MessageEvent) => void; location: Location }
const send = (message: unknown) => self.postMessage(message)
let model: Ort.InferenceSession | undefined
let busy = false
let queued: MessageEvent | undefined
async function init() {
  try {
    self.importScripts('/runtime/ort.wasm.min.js')
    const ort = self.ort
    ort.env.wasm.numThreads = 1
    ort.env.wasm.proxy = false
    ort.env.wasm.wasmPaths = new URL('/runtime/', self.location.href).href
    send({ type: 'progress', text: 'Downloading object model', percent: 0 })
    const manifestResponse = await fetch('/model/manifest.json')
    if (!manifestResponse.ok) throw Error('Model manifest could not download')
    const manifest: { bytes: number; parts: { file: string; bytes: number; sha256: string }[] } = await manifestResponse.json()
    const bytes = new Uint8Array(manifest.bytes)
    let offset = 0
    for (const part of manifest.parts) {
      const response = await fetch('/model/' + part.file)
      if (!response.ok) throw Error('Model download failed. Check your connection and retry.')
      const buffer = await response.arrayBuffer()
      const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', buffer)), b => b.toString(16).padStart(2, '0')).join('')
      if (buffer.byteLength !== part.bytes || digest !== part.sha256) throw Error('Model download was incomplete. Retry loading.')
      bytes.set(new Uint8Array(buffer), offset)
      offset += part.bytes
      send({ type: 'progress', text: 'Downloading object model', percent: Math.round(offset / manifest.bytes * 100) })
    }
    send({ type: 'progress', text: 'Preparing first scan', percent: 100 })
    model = await ort.InferenceSession.create(bytes, { executionProviders: ['wasm'], graphOptimizationLevel: 'all' })
    const warmup = new ort.Tensor('float32', new Float32Array(3 * YOLOX_SIZE ** 2).fill(114), [1, 3, YOLOX_SIZE, YOLOX_SIZE])
    try {
      const outputs = await model.run({ [model.inputNames[0]]: warmup })
      Object.values(outputs).forEach(value => value.dispose())
    } finally { warmup.dispose() }
    send({ type: 'ready' })
  } catch (error) { send({ type: 'failed', error: error instanceof Error ? error.message : String(error) }) }
}
self.onmessage = async event => {
  const { id, width, height, rgba } = event.data
  if (!model || !(rgba instanceof ArrayBuffer) || !Number.isSafeInteger(id)) return
  if (busy) { queued = event; return }
  busy = true
  let input: Ort.Tensor | undefined
  let output: Ort.InferenceSession.OnnxValueMapType | undefined
  const start = performance.now()
  try {
    const prepared = makeYoloInput({ data: new Uint8Array(rgba), width, height })
    input = new self.ort.Tensor('float32', prepared.tensor, [1, 3, YOLOX_SIZE, YOLOX_SIZE])
    output = await model.run({ [model.inputNames[0]]: input })
    const prediction = output[model.outputNames[0]]?.data
    if (!(prediction instanceof Float32Array)) throw Error('Model predictions unavailable')
    const detections = decodeYolo(prediction, prepared.ratio, width, height)
    send({ type: 'result', id, detections, hazards: pathHazards(detections, width, height), width, height,
      milliseconds: Math.round(performance.now() - start) })
  } catch (error) { send({ type: 'error', id, error: error instanceof Error ? error.message : String(error) }) }
  finally {
    input?.dispose(); if (output) Object.values(output).forEach(value => value.dispose()); busy = false
    const next = queued; queued = undefined
    if (next) void self.onmessage(next)
  }
}
void init()
