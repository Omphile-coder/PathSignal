export type Detection = { class: string; score: number; bbox: [number, number, number, number] }
export const corridor = (y: number) => .15 + (y - .28) * .24
export function pathHazards(detections: Detection[], width: number, height: number) {
  return detections.filter(({ bbox: [x, y, w, h], score }) => {
    if (score < .25 || w <= 0 || h <= 0) return false
    const bottom = (y + h) / height
    if (bottom < .28) return false
    const half = corridor(Math.min(.94, bottom))
    const overlap = Math.min((x + w) / width, .5 + half) - Math.max(x / width, .5 - half)
    return overlap >= Math.min(.035, (w / width) * .55)
  }).sort((a, b) => b.score - a.score)
}
