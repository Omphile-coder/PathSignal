import type { Detection } from './path'
export const STAIR_INPUT = 512
export const STAIR_MIN_COVERAGE = .05
export function prepareStairs(data: Uint8Array, width: number, height: number) {
  const size = STAIR_INPUT, plane = size * size
  const tensor = new Float32Array(3 * plane)
  const means = [.485, .456, .406], stds = [.229, .224, .225]
  for (let y = 0; y < size; y++) {
    const sy = Math.max(0, (y + .5) * height / size - .5)
    const y0 = Math.floor(sy), y1 = Math.min(height - 1, y0 + 1), wy = sy - y0
    for (let x = 0; x < size; x++) {
      const sx = Math.max(0, (x + .5) * width / size - .5)
      const x0 = Math.floor(sx), x1 = Math.min(width - 1, x0 + 1), wx = sx - x0
      for (let c = 0; c < 3; c++) {
        const top = data[(y0 * width + x0) * 4 + c] * (1 - wx) + data[(y0 * width + x1) * 4 + c] * wx
        const bottom = data[(y1 * width + x0) * 4 + c] * (1 - wx) + data[(y1 * width + x1) * 4 + c] * wx
        tensor[c * plane + y * size + x] = ((top * (1 - wy) + bottom * wy) / 255 - means[c]) / stds[c]
      }
    }
  }
  return tensor
}
export function decodeStairs(logits: Float32Array, dims: readonly number[], width: number, height: number) {
  const [, classes, rows, cols] = dims
  if (classes !== 150 || !rows || !cols || logits.length !== classes * rows * cols) throw Error('Unexpected stair model output')
  const plane = rows * cols
  let corridorCount = 0, stairCount = 0, allCount = 0, supportSum = 0
  let left = cols, right = -1, top = rows, bottom = -1
  for (let p = 0; p < plane; p++) {
    const x = p % cols, y = Math.floor(p / cols), ny = (y + .5) / rows
    const inside = ny >= .28 && ny <= .94 && Math.abs((x + .5) / cols - .5) <= .15 + (ny - .28) * .24
    if (inside) corridorCount++
    let label = 0, max = logits[p]
    for (let c = 1; c < classes; c++) if (logits[c * plane + p] > max) { max = logits[c * plane + p]; label = c }
    if (label !== 53 && label !== 59) continue
    let denominator = 0
    for (let c = 0; c < classes; c++) denominator += Math.exp(logits[c * plane + p] - max)
    const support = 1 / denominator
    if (!Number.isFinite(support) || support < .5) continue
    allCount++; supportSum += support
    if (inside) stairCount++
    left = Math.min(left, x); right = Math.max(right, x); top = Math.min(top, y); bottom = Math.max(bottom, y)
  }
  const fraction = stairCount / Math.max(1, corridorCount)
  const detections: Detection[] = allCount ? [{ class: 'stairs', score: supportSum / allCount,
    bbox: [left / cols * width, top / rows * height, (right - left + 1) / cols * width, (bottom - top + 1) / rows * height] }] : []
  return { detections, hazards: fraction >= STAIR_MIN_COVERAGE ? detections : [], stairFraction: fraction }
}
