import { prepareStairs, decodeStairs, STAIR_INPUT } from './stairVision'
import type * as Ort from 'onnxruntime-web'
declare const self: { importScripts(url: string): void; ort: typeof Ort; postMessage(message: unknown): void; onmessage: (event: MessageEvent) => void; location: Location }
let model: Ort.InferenceSession | undefined
let busy = false
let queued: MessageEvent | undefined
const send = (message: unknown) => self.postMessage(message)
async function init() {
  try {
    self.importScripts('/runtime/ort.wasm.min.js')
    self.ort.env.wasm.numThreads = 1; self.ort.env.wasm.proxy = false
    self.ort.env.wasm.wasmPaths = new URL('/runtime/', self.location.href).href
    send({ type: 'progress', text: 'Downloading experimental stair model', percent: 0 })
    const metaResponse = await fetch('/model/stairs-manifest.json')
    if (!metaResponse.ok) throw Error('Stair model manifest unavailable')
    const meta = await metaResponse.json()
    const response = await fetch('/model/stairs.onnx')
    if (!response.ok) throw Error('Stair model download failed. Check your connection.')
    const buffer = await response.arrayBuffer()
    const digest = [...new Uint8Array(await crypto.subtle.digest('SHA-256', buffer))].map(b => b.toString(16).padStart(2, '0')).join('')
    if (buffer.byteLength !== meta.bytes || digest !== meta.sha256) throw Error('Stair model integrity check failed. Reload it.')
    send({ type: 'progress', text: 'Preparing experimental stair model', percent: 100 })
    model = await self.ort.InferenceSession.create(buffer, { executionProviders: ['wasm'], graphOptimizationLevel: 'all' })
    send({ type: 'ready', model: 'SegFormer-B0' })
  } catch (error) { send({ type: 'failed', error: error instanceof Error ? error.message : String(error) }) }
}
self.onmessage = async event => {
  const { id, rgba, width, height } = event.data
  if (!model || !(rgba instanceof ArrayBuffer) || !Number.isSafeInteger(id)) return
  if (busy) { queued = event; return }
  busy = true
  const start = performance.now()
  let tensor: Ort.Tensor | undefined
  let output: Ort.InferenceSession.OnnxValueMapType | undefined
  try {
    tensor = new self.ort.Tensor('float32', prepareStairs(new Uint8Array(rgba), width, height), [1, 3, STAIR_INPUT, STAIR_INPUT])
    output = await model.run({ [model.inputNames[0]]: tensor })
    const logits = output[model.outputNames[0]]
    if (!(logits.data instanceof Float32Array)) throw Error('Stair predictions unavailable')
    send({ type: 'result', id, width, height, ...decodeStairs(logits.data, logits.dims, width, height),
      model: 'SegFormer-B0', mode: 'stairs', milliseconds: Math.round(performance.now() - start) })
  } catch (error) { send({ type: 'error', id, error: error instanceof Error ? error.message : String(error) }) }
  finally {
    tensor?.dispose(); if (output) Object.values(output).forEach(value => value.dispose()); busy = false
    const next = queued; queued = undefined; if (next) void self.onmessage(next)
  }
}
void init()
