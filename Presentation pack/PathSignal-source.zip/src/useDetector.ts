import { useEffect, useRef, useState } from 'react'
import type { Detection } from './path'
export type Mode = 'objects' | 'stairs'
export type Result = { id: number; detections: Detection[]; hazards: Detection[]; width: number; height: number; milliseconds: number; model?: string; mode?: Mode; stairFraction?: number }
export function useDetector() {
  const worker = useRef<Worker | null>(null)
  const pending = useRef<{ id: number; resolve(value: Result): void; reject(error: Error): void; timer: ReturnType<typeof setTimeout> } | null>(null)
  const boot = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const serial = useRef(0)
  const [status, setStatus] = useState('idle')
  const [detail, setDetail] = useState('Load the local AI model to begin')
  const [progress, setProgress] = useState(0)
  function cancel() {
    const request = pending.current
    if (request) { clearTimeout(request.timer); pending.current = null; request.reject(Error('Scan cancelled')) }
  }
  function dispose() { clearTimeout(boot.current); cancel(); worker.current?.terminate(); worker.current = null }
  function fail(message: string) { dispose(); setStatus('error'); setDetail(message) }
  function unload() { dispose(); setStatus('idle'); setDetail('Load the local AI model to begin'); setProgress(0) }
  function load(mode: Mode = 'objects') {
    dispose()
    setStatus('loading'); setDetail('Opening local AI model'); setProgress(0)
    const next = new Worker(mode === 'stairs' ? '/model/stairs-worker.js' : '/model/worker.js')
    worker.current = next
    boot.current = setTimeout(() => fail('Model loading timed out. Check your connection and retry.'), 600000)
    next.onerror = () => fail('The model could not start in this browser. Try Safari or Chrome and reload the model.')
    next.onmessage = event => {
      if (worker.current !== next) return
      const message = event.data
      if (message.type === 'progress') { setDetail(message.text); setProgress(message.percent) }
      if (message.type === 'ready') { clearTimeout(boot.current); setStatus('ready'); setDetail(mode === 'stairs' ? 'Experimental stair model ready · SegFormer-B0' : 'YOLOX-S ready · processing stays on this device'); setProgress(100) }
      if (message.type === 'failed') fail(message.error)
      if (['result', 'error'].includes(message.type) && pending.current?.id === message.id) {
        const request = pending.current!
        pending.current = null; clearTimeout(request.timer)
        if (message.type === 'error') request.reject(Error(message.error))
        else request.resolve(message as Result)
      }
    }
  }
  function scan(frame: ImageData): Promise<Result> {
    if (status !== 'ready' || !worker.current) return Promise.reject(Error('Load the model before scanning'))
    if (pending.current) return Promise.reject(Error('A scan is already running'))
    const id = ++serial.current
    const rgba = new Uint8ClampedArray(frame.data).buffer
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        if (pending.current?.id !== id) return
        pending.current = null; reject(Error('Object scan timed out. Reload the model to try again.'))
        fail('Object scan timed out. Reload the model to try again.')
      }, 30000)
      pending.current = { id, resolve, reject, timer }
      worker.current!.postMessage({ id, width: frame.width, height: frame.height, rgba }, [rgba])
    })
  }
  useEffect(() => () => dispose(), [])
  return { load, unload, scan, cancel, status, detail, progress }
}
