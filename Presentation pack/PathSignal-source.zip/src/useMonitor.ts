import { useEffect, useRef, useState } from 'react'
import { useDetector } from './useDetector'
import type { Result } from './useDetector'
export type Log = { timestamp: string; source: string; outcome: string; objects: string; milliseconds: number; spokenAlert: boolean }
function storedLogs(): Log[] {
  try { const raw = JSON.parse(localStorage.getItem('pathsignal-release-log') ?? '[]'); return Array.isArray(raw) ? raw.slice(-200) : [] } catch { return [] }
}
export function useMonitor() {
  const detector = useDetector()
  const video = useRef<HTMLVideoElement>(null)
  const capture = useRef<HTMLCanvasElement>(null)
  const stream = useRef<MediaStream | null>(null)
  const epoch = useRef(0)
  const alive = useRef(true)
  const working = useRef(false)
  const repeat = useRef(false)
  const loopTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const encounters = useRef(new Map<string, number>())
  const [camera, setCamera] = useState(false)
  const [aspect, setAspect] = useState('16 / 9')
  const [opening, setOpening] = useState(false)
  const [scanning, setScanning] = useState(false)
  const [repeating, setRepeating] = useState(false)
  const [status, setStatus] = useState('Ready when you are')
  const [error, setError] = useState('')
  const [source, setSource] = useState('No source selected')
  const [preview, setPreview] = useState('')
  const [result, setResult] = useState<Result | null>(null)
  const [lastAlert, setLastAlert] = useState('')
  const [logs, setLogs] = useState<Log[]>(storedLogs)
  const [storageWarning, setStorageWarning] = useState('')

  function speak(text: string) {
    if (!('speechSynthesis' in window)) { setError('Speech is unavailable in this browser. The alert is shown on screen.'); return }
    speechSynthesis.cancel()
    const message = new SpeechSynthesisUtterance(text)
    message.lang = 'en-GB'; message.rate = 1
    message.onerror = event => { if (event.error !== 'interrupted' && event.error !== 'canceled' && alive.current) setError('Audio could not play. Check sound settings and tap Test audio.') }
    speechSynthesis.speak(message)
  }
  function pauseLoop() { repeat.current = false; setRepeating(false); clearTimeout(loopTimer.current) }
  function stop(announce = false) {
    epoch.current++; pauseLoop(); detector.cancel(); working.current = false; setScanning(false); setOpening(false)
    const hadCamera = !!stream.current
    stream.current?.getTracks().forEach(track => { track.onended = null; track.stop() })
    stream.current = null
    if (video.current) video.current.srcObject = null
    setCamera(false); encounters.current.clear(); setResult(null)
    setStatus('Camera stopped. Alerts are paused.')
    if (announce && hadCamera) speak('Obstacle alerts paused. Camera stopped.')
  }
  function pause(message: string) { stop(); setError(message); setStatus('Obstacle alerts paused'); speak('Obstacle alerts paused. ' + message) }
  async function startCamera() {
    stop(); setError(''); setOpening(true); setPreview(''); setSource('Live camera'); setStatus('Opening rear camera')
    const token = epoch.current
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw Error('Camera access needs HTTPS and a supported browser.')
      const next = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false })
      if (token !== epoch.current || !alive.current) { next.getTracks().forEach(track => track.stop()); return }
      stream.current = next
      const element = video.current
      if (!element) throw Error('Camera preview unavailable')
      element.srcObject = next
      await element.play()
      if (token !== epoch.current || !alive.current) return
      next.getVideoTracks().forEach(track => { track.onended = () => pause('Camera access ended. Start the camera again.') })
      setAspect(`${element.videoWidth} / ${element.videoHeight}`)
      setCamera(true); setOpening(false); setStatus('Camera ready. Stand still and scan.')
      if (detector.status === 'idle' || detector.status === 'error') detector.load()
    } catch (failure) {
      if (token !== epoch.current || !alive.current) return
      const message = failure instanceof DOMException && failure.name === 'NotAllowedError' ? 'Camera permission was denied. Allow camera access in browser settings.' : failure instanceof Error ? failure.message : 'Camera could not start.'
      pause(message)
    }
  }
  async function processFrame(image: CanvasImageSource, width: number, height: number, name: string) {
    if (working.current) return
    const canvas = capture.current
    if (!canvas) return
    const token = epoch.current
    working.current = true; setScanning(true); setError(''); setStatus('Checking for objects')
    try {
      const scale = Math.min(1, 480 / Math.max(width, height))
      canvas.width = Math.max(1, Math.round(width * scale)); canvas.height = Math.max(1, Math.round(height * scale))
      const context = canvas.getContext('2d', { willReadFrequently: true })
      if (!context) throw Error('Image processing is unavailable')
      context.drawImage(image, 0, 0, canvas.width, canvas.height)
      const next = await detector.scan(context.getImageData(0, 0, canvas.width, canvas.height))
      if (token !== epoch.current || !alive.current) return
      const present = new Set(next.hazards.map(item => item.class))
      for (const [label, misses] of encounters.current) if (!present.has(label)) {
        if (misses >= 1) encounters.current.delete(label)
        else encounters.current.set(label, misses + 1)
      }
      const fresh = [...present].filter(label => !encounters.current.has(label))
      present.forEach(label => encounters.current.set(label, 0))
      const alert = fresh.length ? 'Possible ' + fresh.slice(0, 2).join(' and ') + ' ahead.' : ''
      if (alert) { setLastAlert(alert); speak(alert) }
      setResult(next); setSource(name)
      setStatus(next.hazards.length ? 'Possible obstacle in the corridor' : 'No alert on this scan')
      setLogs(current => [...current, { timestamp: new Date().toISOString(), source: name,
        outcome: next.hazards.length ? 'possible_obstacle' : 'no_alert', objects: [...new Set(next.detections.map(item => item.class))].join(', '), milliseconds: next.milliseconds, spokenAlert: !!alert }].slice(-200))
    } catch (failure) {
      if (token !== epoch.current || !alive.current) return
      pauseLoop(); setError(failure instanceof Error ? failure.message : 'The image could not be processed.')
      setStatus('Obstacle alerts paused'); speak('Obstacle alerts paused. The image could not be processed.')
    } finally { if (token === epoch.current && alive.current) { working.current = false; setScanning(false) } }
  }
  async function scanCamera() {
    const element = video.current
    if (!stream.current || !element) return
    if (element.readyState < 2 || !element.videoWidth) { pause('The camera image is unavailable. Start the camera again.'); return }
    await processFrame(element, element.videoWidth, element.videoHeight, 'Live camera')
  }
  async function loop() {
    if (!repeat.current) return
    await scanCamera()
    if (repeat.current) loopTimer.current = setTimeout(() => void loop(), 700)
  }
  function toggleRepeat() {
    if (repeat.current) { pauseLoop(); return }
    repeat.current = true; setRepeating(true); void loop()
  }
  async function sample(url: string, name: string) {
    stop(); setError(''); setPreview(url); setSource(name); setStatus('Opening sample image')
    const token = epoch.current
    try {
      const image = new Image()
      await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(Error('Sample image could not open')); image.src = url })
      if (token !== epoch.current || !alive.current) return
      await processFrame(image, image.naturalWidth, image.naturalHeight, name)
    } catch (failure) { if (token === epoch.current) { setError(String(failure)); setStatus('Sample unavailable') } }
  }
  useEffect(() => { alive.current = true; return () => { alive.current = false; epoch.current++; clearTimeout(loopTimer.current); stream.current?.getTracks().forEach(track => track.stop()); if ('speechSynthesis' in window) speechSynthesis.cancel() } }, [])
  useEffect(() => {
    try { localStorage.setItem('pathsignal-release-log', JSON.stringify(logs)) }
    catch { setStorageWarning('This browser could not save the log. Export it before closing the page.') }
  }, [logs])
  useEffect(() => {
    const hide = () => { if (document.hidden && stream.current) { stop(); setStatus('Alerts paused because the app moved to the background.'); speak('Obstacle alerts paused.') } }
    document.addEventListener('visibilitychange', hide)
    return () => document.removeEventListener('visibilitychange', hide)
  }, [])
  useEffect(() => { if (detector.status === 'error' && stream.current) pause('The object model is unavailable. Reload the model.') }, [detector.status])
  return { detector, video, capture, camera, aspect, opening, scanning, repeating, status, error, source, preview, result, lastAlert, logs, storageWarning,
    startCamera, stop: () => stop(true), scanCamera, toggleRepeat, sample, testAudio: () => speak('PathSignal audio check.'), repeatAlert: () => speak(lastAlert), clearLogs: () => setLogs([]) }
}
