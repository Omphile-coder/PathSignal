# Browser release verification

18 November 2026. These results describe development checks on this PC.

The static production build passed TypeScript checking. The SHA-256 check passed for both pretrained model parts. The dependency audit reported zero known vulnerabilities for the final dependency set.

The acceptance script processed the saved bottle and empty-floor images with the actual worker, WASM runtime and YOLOX-S model in desktop WebKit and Chromium. Both recognised the bottle and returned no alert on the empty-floor image. It also exercised user-selected image loading, speech requests, CSV download, local log restoration and a 390-pixel layout without page overflow.

Chromium additionally exercised camera acquisition through a canvas-backed MediaStream, repeated scans, suppression of duplicate class alerts, re-arming after two absent scans, release of the track on Stop, and the paused state after a rejected camera-permission request.

`chromium-results.json` and `webkit-results.json` contain the observations. Screenshots show desktop and mobile-width layouts. To repeat, run `npm run build`, start `npm run preview`, then run `node scripts/acceptance.mjs` and `node scripts/acceptance.mjs --webkit`. Playwright browsers must be installed for those scripts.

The speech API was replaced with a recording stub in browser automation. The checks observed speech requests, not audible sound. The camera stream was injected and does not verify a physical camera. No physical iPhone Safari, VoiceOver, distance, walking or statistically meaningful recognition evaluation was performed in this release workflow.

## 20 November stair extension

`check-stairs.mjs` exercises the experimental mode, speech requests, model-tagged log entries, mode reset and mobile layout. Use `--webkit` for the second browser. Use `--frames` with the locally extracted development frames to reproduce `stair-development-frames.json`. Original user labels for the two stair clips were reversed relative to the visible view and are annotated explicitly in the report. The downward-looking example is a known miss. No metric distance is generated.
